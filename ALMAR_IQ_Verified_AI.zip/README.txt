ALMAR IQ — Verified AI

FITUR
- Secure server-side API key
- Rate limiting
- Security headers
- Input validation
- Short conversation context
- Low-temperature responses for consistency
- Honest uncertainty rules
- Safe calculator endpoint
- Generic client-facing errors (server logs details)

CARA MENJALANKAN
1. Install Node.js 18+.
2. Jalankan: npm install
3. Set environment variable OPENAI_API_KEY di server.
4. Opsional: OPENAI_MODEL (default: gpt-5-mini)
5. Jalankan: npm start
6. Buka http://localhost:3000

PENTING
Jangan pernah menaruh OPENAI_API_KEY di HTML, JavaScript frontend,
localStorage, atau repository publik.
