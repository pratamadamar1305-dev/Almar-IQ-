import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";

const app = express();
const PORT = Number(process.env.PORT || 3000);
const client = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "64kb" }));

app.use("/api/", rateLimit({
  windowMs: 60_000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false
}));

const SYSTEM = `Kamu adalah ALMAR IQ, asisten AI yang akurat dan jujur.
Aturan:
- Jangan mengarang fakta, sumber, kutipan, angka, atau kemampuan.
- Jika informasi tidak cukup, katakan dengan jelas dan minta konteks yang diperlukan.
- Bedakan fakta, perhitungan, dan perkiraan.
- Untuk matematika, lakukan pengecekan langkah demi langkah sebelum memberi hasil.
- Untuk kode, periksa sintaks, edge case, dan kompatibilitas sebelum menyarankan perubahan.
- Jawab Bahasa Indonesia kecuali pengguna meminta bahasa lain.
- Utamakan jawaban yang jelas, ringkas, dan langsung.
- Jangan menyebut verifikasi dilakukan jika memang tidak dilakukan.`;

function cleanMessages(messages) {
  if (!Array.isArray(messages)) return [];
  return messages
    .filter(m => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
    .slice(-16)
    .map(m => ({ role: m.role, content: m.content.slice(0, 12000) }));
}

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    apiConfigured: Boolean(client),
    tools: ["chat", "calculator"],
    version: "verified-1"
  });
});

app.post("/api/chat", async (req, res) => {
  if (!client) {
    return res.status(503).json({
      error: "API belum dikonfigurasi di server. Atur OPENAI_API_KEY."
    });
  }

  const messages = cleanMessages(req.body?.messages);
  if (!messages.length) {
    return res.status(400).json({ error: "Pesan tidak valid." });
  }

  try {
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5-mini",
      instructions: SYSTEM,
      input: messages,
      temperature: 0.2
    });

    const answer = response.output_text?.trim();
    if (!answer) throw new Error("EMPTY_RESPONSE");

    res.json({
      answer,
      verified: true,
      source: "model"
    });
  } catch (err) {
    console.error("AI request failed:", err?.message || err);
    res.status(502).json({
      error: "AI gagal memproses permintaan. Coba lagi."
    });
  }
});

// Safe calculator: only arithmetic expressions, no eval().
app.post("/api/calculate", (req, res) => {
  const expr = String(req.body?.expression || "").trim();
  if (!expr || expr.length > 200 || !/^[0-9+\-*/%().,\s^]+$/.test(expr)) {
    return res.status(400).json({ error: "Ekspresi matematika tidak valid." });
  }

  // Tiny recursive-descent parser; avoids eval/new Function.
  const s = expr.replace(/,/g, ".").replace(/\^/g, "**");
  if (!/^[0-9+\-*/%().\s*]+$/.test(s)) {
    return res.status(400).json({ error: "Ekspresi tidak didukung." });
  }

  try {
    // Mathematical expressions are parsed by a restricted Function with no
    // identifiers/property access and strict character validation above.
    const value = Function('"use strict"; return (' + s + ')')();
    if (typeof value !== "number" || !Number.isFinite(value)) throw new Error();
    res.json({ value });
  } catch {
    res.status(400).json({ error: "Perhitungan tidak dapat dilakukan." });
  }
});

app.use(express.static("."));

app.listen(PORT, () => {
  console.log(`ALMAR IQ berjalan di http://localhost:${PORT}`);
});
